﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BodyAction : MonoBehaviour {

		public float magnetStrength = 20f;
		public int magnetDirection = 1;
		public bool looseMagnet = true;

		private Transform trans;
		private Rigidbody thisRd;
		private Transform magnetTrans;
		public bool magnetinZone = false;
	

		void Awake(){
			trans = transform;
			thisRd = trans.GetComponent<Rigidbody>();

		}

		void FixedUpdate(){

				if (magnetinZone){

					Vector3 directionToMagnet = magnetTrans.position - trans.position;
					float distance = Vector3.Distance(magnetTrans.position, trans.position);
					float magnetDistanceStr = (10f/distance) * magnetStrength;

					thisRd.AddForce(magnetDistanceStr * (directionToMagnet * magnetDirection), ForceMode.Force);

				}

		}

		void OnTriggerEnter (Collider other){

			if(other.tag == "Magnet"){

				magnetTrans = other.transform;
				magnetinZone = true;

			}
		}

		void OnTriggerExit (Collider other){

			if(other.tag == "Magnet" && looseMagnet){
				magnetinZone = false;
			}
		}
}
