using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainCamera : MonoBehaviour {
		[SerializeField]
		private float _sensitivityY = 2.0f;
		[SerializeField]
		private float _sensitivityX = 2.0f;
		[SerializeField]
    private float Speed = 6.0f;
    [SerializeField]
    private float Gravity = 4.5f;
    private Vector3 direction = Vector3.zero;
	// Use this for initialization
	void Start () {
		Cursor.lockState = CursorLockMode.Locked;
	}

	// Update is called once per frame
	void Update () {
			float _mouseX = Input.GetAxis("Mouse X");
			float _mouseY = Input.GetAxis("Mouse Y");
			Vector3 newRotation = transform.localEulerAngles;
			newRotation.y += _mouseX * _sensitivityY;
			transform.localEulerAngles = newRotation;


        Vector3 newRotationY = transform.localEulerAngles;
        newRotationY.x -= _mouseY*_sensitivityX;
        transform.localEulerAngles = newRotationY;

				if (Input.GetKeyDown(KeyCode.Escape))
        {
            Cursor.visible = true;
            Cursor.lockState = CursorLockMode.None;
        }

			CalculateMovement();
	}

		public void CalculateMovement(){

					float HorizontalInput = Input.GetAxis("Horizontal");
	        float VerticalInput = Input.GetAxis("Vertical");
	        CharacterController controller = GetComponent<CharacterController>();
	        Vector3 direction = new Vector3(HorizontalInput, 0, VerticalInput);
	        Vector3 velocity = direction * Speed;
					if(Input.GetKey("space")){
						velocity.y += Gravity ;
					}
					if(Input.GetKey(KeyCode.LeftShift)){
						velocity.y -= Gravity ;
					}

	        velocity = transform.transform.TransformDirection(velocity);
	        controller.Move(velocity * Time.deltaTime);


	}

}
