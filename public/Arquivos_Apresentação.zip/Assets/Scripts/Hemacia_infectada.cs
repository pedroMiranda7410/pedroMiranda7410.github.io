﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hemacia_infectada : MonoBehaviour {


	public float FloatStrenght = 1.2f;
	public float RandomRotationStrenght= 0.9f;
	public float _speedRotationUP = 4.5f;
	public float _speedFoward = 10.0f;
	Rigidbody rigidbody;
	public bool destroy_hemacia = false;

	public BodyAction forcaMagneticaInfectada;

	// Use this for initialization
	void Start () {
		rigidbody = GetComponent<Rigidbody> ();
		forcaMagneticaInfectada = GameObject.Find("Hemacia_infectada").GetComponent<BodyAction>();
	}

	// Update is called once per frame
	void Update () {

		if(forcaMagneticaInfectada.magnetinZone == false){
			rigidbody.velocity = new Vector3 (0f, 0f, _speedFoward);
			transform.Rotate(0.9f, 0f, 0f);
			if(destroy_hemacia == true){
				destroy_hemacia = false;
				Destroy(this.gameObject);

			}
		}
	}
}
