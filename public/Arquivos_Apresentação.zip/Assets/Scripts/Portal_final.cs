﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal_final : MonoBehaviour {

	public Hemacia_apresentacao hemacia;
	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame

	public void OnTriggerEnter(Collider other)
	{

		if(other.tag == "Hemacia")
{
	 Destroy(other.gameObject);
	 hemacia.destroy_hemacia = true;
}
	 }

	}
