﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal_hemacia : MonoBehaviour {


	public GameObject _hemacia;
	public GameObject _hemaciaInfectada;
	public bool hemacia_spawn = true;
	public bool hemacia_infectada_spawn = true;

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {

		if(hemacia_spawn == true){
			hemacia_spawn = false;
			StartCoroutine(spawn());

		}

		if(hemacia_infectada_spawn == true){
			hemacia_infectada_spawn = false;
			StartCoroutine(spawnInfeccao());
		}



	}

	private static Vector3 RandomPointInBox(Vector3 center, Vector3 size) {

						return center + new Vector3(
							 (Random.value - 0.5f) * size.x,
							 (Random.value - 0.5f) * size.y,
							  size.z
						);
				}

	IEnumerator spawn(){

		yield return new WaitForSeconds(1.5f);
		Instantiate(_hemacia,RandomPointInBox(transform.position,transform.localScale) , transform.rotation);
		hemacia_spawn = true;

	}

	IEnumerator spawnInfeccao(){

		yield return new WaitForSeconds(10.0f);
		Instantiate(_hemaciaInfectada,RandomPointInBox(transform.position,transform.localScale) , transform.rotation);
		hemacia_spawn = true;

	}
}
