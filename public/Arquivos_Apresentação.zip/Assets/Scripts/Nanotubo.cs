﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nanotubo : MonoBehaviour {

	public float FloatStrenght = 1.2f;
	public float RandomRotationStrenght= 0.9f;
	public float _speedRotationUP = 4.5f;
	public float _speedFoward = 0.01f;
	Rigidbody rigidbody;

	// Use this for initialization
	void Start () {

	rigidbody = GetComponent<Rigidbody> ();

	}

	// Update is called once per frame
	void Update () {
		//rigidbody.velocity = new Vector3 (0f, 0f, 0f);
		transform.Rotate(0.1f, 0f, 0f);
	}
}
